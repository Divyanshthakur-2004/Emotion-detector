import cv2
from deepface import DeepFace
import matplotlib.pyplot as plt
import numpy as np

# Load face cascade classifier
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Start capturing video
cap = cv2.VideoCapture(0)

def handle_close(event):
    global running
    running = False

# Create a figure for matplotlib
fig = plt.figure()
fig.canvas.mpl_connect('close_event', handle_close)

running = True

while running:
    # Capture frame-by-frame
    ret, frame = cap.read()
    if not ret:
        break

    # Convert frame to grayscale
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Convert grayscale frame to RGB format
    rgb_frame = cv2.cvtColor(gray_frame, cv2.COLOR_GRAY2RGB)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        # Extract the face ROI (Region of Interest)
        face_roi = rgb_frame[y:y + h, x:x + w]

        # Perform emotion analysis on the face ROI
        result = DeepFace.analyze(face_roi, actions=['emotion'], enforce_detection=False)

        # Determine the dominant emotion
        emotion = result[0]['dominant_emotion']

        # Draw rectangle around face and label with predicted emotion
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
        cv2.putText(frame, emotion, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)

    # Convert frame to RGB for matplotlib
    rgb_display_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Display the resulting frame using matplotlib
    plt.imshow(rgb_display_frame)
    plt.axis('off')
    plt.draw()
    plt.pause(0.001)
    plt.clf()

    # Check for 'q' key press to exit
    if plt.get_fignums():
        fig.canvas.flush_events()
    else:
        break

# Release the capture
cap.release()
plt.close()



# import speech_recognition as sr
# import librosa
# import numpy as np
# import cv2

# # Step 1: Audio Input
# def record_audio():
#     recognizer = sr.Recognizer()
#     with sr.Microphone() as source:
#         print("Please say something...")
#         audio = recognizer.listen(source)
#     return audio

# # Step 2: Audio Processing
# def extract_audio_features(audio):
#     # Convert audio to numpy array
#     y, sr = librosa.load(sr.AudioData(audio.get_raw_data(), audio.SAMPLE_RATE), sr=None)
#     # Extract features (e.g., mean, standard deviation of spectral centroid)
#     spectral_centroids = librosa.feature.spectral_centroid(y=y, sr=sr)[0]
#     features = [np.mean(spectral_centroids), np.std(spectral_centroids)]
#     return features

# # Step 3: Emotion Recognition from Audio
# def detect_emotion_from_audio(features):
#     # Placeholder for emotion detection from audio (you can replace this with your own model)
#     # Example: Simple classification based on features
#     # In real-world scenarios, you would need a trained model.
#     if features[0] > 1000:
#         emotion = "happy"
#     else:
#         emotion = "sad"
#     return emotion

# # Step 4: Facial Expression Recognition
# def detect_emotion_from_face():
#     # Placeholder for facial expression recognition (you can replace this with your own model)
#     # Example: Using Haar Cascade Classifier for face detection and capturing facial expressions
#     face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
#     cap = cv2.VideoCapture(0)  # Access the webcam
#     while True:
#         ret, frame = cap.read()
#         gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#         faces = face_cascade.detectMultiScale(gray, 1.3, 5)
#         for (x, y, w, h) in faces:
#             cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
#             roi_gray = gray[y:y + h, x:x + w]
#             roi_color = frame[y:y + h, x:x + w]
#             # Placeholder: You can implement facial expression recognition here
#             # Example: Analyzing facial features using deep learning models
#         cv2.imshow('frame', frame)
#         if cv2.waitKey(1) & 0xFF == ord('q'):
#             break
#     cap.release()
#     cv2.destroyAllWindows()

# # Step 5: Main Function
# def main():
#     # Step 1: Audio Input
#     audio = record_audio()
#     # Step 2: Audio Processing
#     audio_features = extract_audio_features(audio)
#     # Step 3: Emotion Recognition from Audio
#     audio_emotion = detect_emotion_from_audio(audio_features)
#     print("Emotion detected from audio:", audio_emotion)
#     # Step 4: Facial Expression Recognition
#     detect_emotion_from_face()

# if __name__ == "__main__":
#     main()
