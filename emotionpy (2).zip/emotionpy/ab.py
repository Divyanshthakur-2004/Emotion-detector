# import numpy 

# a = [1,2,3,4,5,6]

# print(numpy.percentile(a,30))


